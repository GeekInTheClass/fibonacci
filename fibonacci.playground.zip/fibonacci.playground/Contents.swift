//: Playground - noun: a place where people can play

import UIKit
//n은 3 이상!!!!!!!!!!
func fibonacci (n: Int) -> Int { //n번째 피보나치 숫자 만들기
    var first: Int
    var second: Int
    var sum: Int
    //first, second, sum을 이용하여 피보나치 숫자 만들기
    //
    return sum //sum이 n번째 피보나치 숫자
}
